create view V_$REPLAY_CONTEXT_SYSTIMESTAMP as
select "CONTEXT_ID","SYSTIMESTAMP_VALUE","REPLAYED","CON_ID" from v$replay_context_systimestamp
