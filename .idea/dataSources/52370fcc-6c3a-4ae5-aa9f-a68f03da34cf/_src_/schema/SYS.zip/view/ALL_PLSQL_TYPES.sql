create view ALL_PLSQL_TYPES as
select u.name, t.typ_name || decode(bitand(t.properties,134217728),134217728,
                                    '%ROWTYPE', null),
       o.name, t.toid,
       decode(t.typecode, 250,
                          decode(bitand(t.properties,134217728),134217728,
                          'CURSOR ROWTYPE', 'PL/SQL RECORD'),
                          122, 'COLLECTION',
                          'UNKNOWN TYPECODE: ' || t.typecode),
       t.attributes,
       decode(bitand(t.properties, 67108864), 67108864, 'YES', 0, 'NO')
from sys.user$ u, sys.type$ t, sys."_CURRENT_EDITION_OBJ" o
where o.owner# = u.user#
  and o.type# <> 10 -- must not be invalid
  and t.package_obj# IS NOT NULL                          -- only package types
  and o.obj# = t.package_obj#
  and (o.owner# = userenv('SCHEMAID')
       or
       o.obj# in (select oa.obj#
                  from sys.objauth$ oa
                  where grantee# in (select kzsrorol
                                     from x$kzsro))
       or /* user has system privileges */
       exists (select null from v$enabledprivs
               where priv_number in (-144 /* EXECUTE ANY PROCEDURE */,
                                     -141 /* CREATE ANY PROCEDURE */
                                     -241 /* DEBUG ANY PROCEDURE */)))
