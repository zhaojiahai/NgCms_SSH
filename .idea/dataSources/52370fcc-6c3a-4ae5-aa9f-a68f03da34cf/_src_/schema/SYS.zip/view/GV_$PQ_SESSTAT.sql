create view GV_$PQ_SESSTAT as
select "INST_ID","STATISTIC","LAST_QUERY","SESSION_TOTAL","CON_ID" from gv$pq_sesstat
