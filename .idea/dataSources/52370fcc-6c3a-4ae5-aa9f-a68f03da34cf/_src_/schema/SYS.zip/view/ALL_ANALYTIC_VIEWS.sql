create view ALL_ANALYTIC_VIEWS as
select OWNER,
       ANALYTIC_VIEW_NAME,
       TABLE_OWNER,
       TABLE_NAME,
       TABLE_ALIAS,
       DEFAULT_AGGR,
       DEFAULT_MEASURE,
       COMPILE_STATE,
       ORIGIN_CON_ID
from INT$DBA_AVIEWS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, ANALYTIC_VIEW_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
