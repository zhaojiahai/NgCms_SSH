create view GV_$ACTIVE_SESS_POOL_MTH as
select "INST_ID","NAME","CON_ID" from gv$active_sess_pool_mth
