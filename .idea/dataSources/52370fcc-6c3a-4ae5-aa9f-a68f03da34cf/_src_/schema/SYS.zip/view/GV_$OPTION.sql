create view GV_$OPTION as
select "INST_ID","PARAMETER","VALUE","CON_ID" from gv$option
