create view USER_PART_KEY_COLUMNS as
select
  NAME, OBJECT_TYPE, COLUMN_NAME, COLUMN_POSITION, COLLATED_COLUMN_ID
from user_part_key_columns_v$
