create view USER_TAB_STATS_HISTORY as
select o.name, null, null, h.savtime
  from   sys.obj$ o, sys.wri$_optstat_tab_history h
  where  h.obj# = o.obj# and o.type# = 2
    and  o.owner# = userenv('SCHEMAID')
    and  h.savtime <= systimestamp  -- exclude pending statistics
  union all
  -- partitions
  select o.name, o.subname, null, h.savtime
  from   sys.obj$ o, sys.wri$_optstat_tab_history h
  where  h.obj# = o.obj# and o.type# = 19
    and  o.owner# = userenv('SCHEMAID')
    and  h.savtime <= systimestamp  -- exclude pending statistics
  union all
  -- sub partitions
  select osp.name, ocp.subname, osp.subname, h.savtime
  from  sys.obj$ osp, sys.obj$ ocp,  sys.tabsubpart$ tsp,
        sys.wri$_optstat_tab_history h
  where h.obj# = osp.obj# and osp.type# = 34 and osp.obj# = tsp.obj#
    and tsp.pobj# = ocp.obj# and osp.owner# = userenv('SCHEMAID')
    and h.savtime <= systimestamp  -- exclude pending statistics
  union all
  -- fixed tables
  select t.kqftanam, null, null, h.savtime
  from  sys.x$kqfta t, sys.wri$_optstat_tab_history h
  where t.kqftaobj = h.obj#
    and userenv('SCHEMAID') = 0  /* SYS */
    and  h.savtime <= systimestamp  -- exclude pending statistics
