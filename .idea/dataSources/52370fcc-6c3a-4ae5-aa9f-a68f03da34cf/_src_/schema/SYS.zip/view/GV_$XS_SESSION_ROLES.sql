create view GV_$XS_SESSION_ROLES as
select "INST_ID","ROLE_WSPACE","ROLE_NAME","FLAGS","CON_ID" from gv$xs_session_role
