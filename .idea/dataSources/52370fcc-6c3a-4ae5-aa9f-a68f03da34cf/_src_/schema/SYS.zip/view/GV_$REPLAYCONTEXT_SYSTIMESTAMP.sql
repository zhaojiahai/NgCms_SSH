create view GV_$REPLAYCONTEXT_SYSTIMESTAMP as
select "INST_ID","CONTEXT_ID","SYSTIMESTAMP_VALUE","REPLAYED","CON_ID" from gv$replay_context_systimestamp
