create view ALL_EDITION_COMMENTS as
select o.name, c.comment$
from sys.obj$ o, sys.com$ c
where o.obj# = c.obj# (+)
  and o.type# = 57
