create view GV_$LOADISTAT as
select "INST_ID","OWNER","TABNAME","INDEXNAME","SUBNAME","MESSAGE_NUM","MESSAGE","CON_ID" from gv$loadistat
