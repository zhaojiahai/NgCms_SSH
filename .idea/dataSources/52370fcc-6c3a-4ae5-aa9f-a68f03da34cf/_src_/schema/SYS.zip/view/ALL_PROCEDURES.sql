create view ALL_PROCEDURES as
select OWNER, OBJECT_NAME, PROCEDURE_NAME, OBJECT_ID, SUBPROGRAM_ID,
       OVERLOAD, OBJECT_TYPE,
       AGGREGATE, PIPELINED,
       IMPLTYPEOWNER, IMPLTYPENAME, PARALLEL,
       INTERFACE, DETERMINISTIC, AUTHID, RESULT_CACHE, ORIGIN_CON_ID
  from INT$DBA_PROCEDURES
 where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
    or exists
       (select null from v$enabledprivs where priv_number in (-144,-141))
    or OBJ_ID(OWNER, OBJECT_NAME, OBJECT_TYPE#, OBJECT_ID) in
       (select obj#
          from sys.objauth$
         where grantee# in (select kzsrorol from x$kzsro)
           and privilege# = 12)
