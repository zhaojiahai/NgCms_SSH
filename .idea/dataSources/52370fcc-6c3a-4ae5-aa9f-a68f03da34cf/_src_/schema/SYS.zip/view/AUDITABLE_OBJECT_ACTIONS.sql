create view AUDITABLE_OBJECT_ACTIONS as
select INDX, ACTION_NAME from x$aud_obj_actions
