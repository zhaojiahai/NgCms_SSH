create view LOADER_DB_OPEN_READ_WRITE as
select count(*) from v$database where open_mode = 'READ WRITE'
