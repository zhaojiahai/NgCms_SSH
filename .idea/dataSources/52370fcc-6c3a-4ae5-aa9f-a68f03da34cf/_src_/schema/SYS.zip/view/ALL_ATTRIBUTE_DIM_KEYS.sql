create view ALL_ATTRIBUTE_DIM_KEYS as
select OWNER,
       DIMENSION_NAME,
       LEVEL_NAME,
       IS_ALTERNATE,
       ATTRIBUTE_NAME,
       ATTR_ORDER_NUM,
       KEY_ORDER_NUM,
       ORIGIN_CON_ID
from INT$DBA_ATTR_DIM_KEYS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, DIMENSION_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
