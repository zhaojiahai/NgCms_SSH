create view GV_$TIMEZONE_FILE as
select "FILENAME","VERSION","CON_ID" from gv$timezone_file
