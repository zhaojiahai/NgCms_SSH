create view ALL_MINING_MODEL_XFORMS as
select u.name, o.name, x.attr, x.subn, x.attrspec, x.expr,
       decode(bitand(x.properties,16),16,'YES','NO')
from sys.obj$ o, sys.user$ u, sys.modelxfm$ x
where o.obj#=x.mod#
  and o.owner#=u.user#
  and bitand(x.properties,256) != 0
  and (o.owner#=userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where oa.grantee# in ( select kzsrorol
                                         from x$kzsro
                                  )
            )
        or /* user has system privileges */
          ora_check_sys_privilege (o.owner#, o.type#) = 1
      )
