create view V_$TIMEZONE_NAMES as
select "TZNAME","TZABBREV","CON_ID" from v$timezone_names
