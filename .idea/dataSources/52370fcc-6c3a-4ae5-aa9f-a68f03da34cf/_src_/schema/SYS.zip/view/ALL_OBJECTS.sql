create view ALL_OBJECTS as
select u.name, o.name, o.subname, o.obj#, o.dataobj#,
       decode(o.type#, 0, 'NEXT OBJECT', 1, 'INDEX', 2, 'TABLE', 3, 'CLUSTER',
                      4, 'VIEW', 5, 'SYNONYM', 6, 'SEQUENCE',
                      7, 'PROCEDURE', 8, 'FUNCTION', 9, 'PACKAGE',
                      
                      11, 'PACKAGE BODY', 12, 'TRIGGER',
                      13, 'TYPE', 14, 'TYPE BODY',
                      19, 'TABLE PARTITION', 20, 'INDEX PARTITION', 21, 'LOB',
                      22, 'LIBRARY', 23, 'DIRECTORY', 24, 'QUEUE',
                      28, 'JAVA SOURCE', 29, 'JAVA CLASS', 30, 'JAVA RESOURCE',
                      32, 'INDEXTYPE', 33, 'OPERATOR',
                      34, 'TABLE SUBPARTITION', 35, 'INDEX SUBPARTITION',
                      40, 'LOB PARTITION', 41, 'LOB SUBPARTITION',
                      42, CASE (SELECT BITAND(s.xpflags, 8388608 + 34359738368)
                                FROM sum$ s
                                WHERE s.obj#=o.obj#)
                          WHEN 8388608 THEN 'REWRITE EQUIVALENCE'
                          WHEN 34359738368 THEN 'MATERIALIZED ZONEMAP'
                          ELSE 'MATERIALIZED VIEW'
                          END,
                      43, 'DIMENSION',
                      44, 'CONTEXT', 46, 'RULE SET', 47, 'RESOURCE PLAN',
                      48, 'CONSUMER GROUP',
                      55, 'XML SCHEMA', 56, 'JAVA DATA',
                      57, 'EDITION', 59, 'RULE',
                      60, 'CAPTURE', 61, 'APPLY',
                      62, 'EVALUATION CONTEXT',
                      66, 'JOB', 67, 'PROGRAM', 68, 'JOB CLASS', 69, 'WINDOW',
                      72, 'SCHEDULER GROUP', 74, 'SCHEDULE', 79, 'CHAIN',
                      81, 'FILE GROUP', 82, 'MINING MODEL', 87, 'ASSEMBLY',
                      90, 'CREDENTIAL', 92, 'CUBE DIMENSION', 93, 'CUBE',
                      94, 'MEASURE FOLDER', 95, 'CUBE BUILD PROCESS',
                      100, 'FILE WATCHER', 101, 'DESTINATION',
                      114, 'SQL TRANSLATION PROFILE',
                      115, 'UNIFIED AUDIT POLICY',
                      144, 'MINING MODEL PARTITION',
                      148, 'LOCKDOWN PROFILE',
                      150, 'HIERARCHY',
                      151, 'ATTRIBUTE DIMENSION',
                      152, 'ANALYTIC VIEW',
                     'UNDEFINED'),
       o.ctime, o.mtime,
       to_char(o.stime, 'YYYY-MM-DD:HH24:MI:SS'),
       decode(o.status, 0, 'N/A', 1, 'VALID', 'INVALID'),
       decode(bitand(o.flags, 2), 0, 'N', 2, 'Y', 'N'),
       decode(bitand(o.flags, 4), 0, 'N', 4, 'Y', 'N'),
       decode(bitand(o.flags, 16), 0, 'N', 16, 'Y', 'N'),
       o.namespace,
       o.defining_edition,
       decode(bitand(o.flags, (65536+131072+4294967296)),
              4294967296+65536, 'EXTENDED DATA LINK', 65536, 'METADATA LINK',
              131072, 'DATA LINK', 'NONE'),
       case when o.type# in (4,5,7,8,9,11,12,13,14,22,87,114) then
           decode(bitand(o.flags, 1048576), 0, 'Y', 1048576, 'N', 'Y')
         else null end,
       decode(bitand(o.flags, 4194304), 4194304, 'Y', 'N'),
       decode(bitand(o.flags, 134217728), 134217728, 'Y', 'N'),
       case when o.type# in (2,4,7,8,9,12,13) then
           nls_collation_name(nvl(o.dflcollid, 16382))
         when (o.type# = 42
               and exists
               (SELECT 1
                FROM sum$ s
                WHERE s.obj#=o.obj#
                -- not rewrite equivalence or zone map
                and bitand(s.xpflags, 8388608 + 34359738368) = 0)) then
           nls_collation_name(nvl(o.dflcollid, 16382))
         else null end,
       decode(bitand(o.flags, 2147483648), 0, 'N', 2147483648, 'Y', 'N'),
       decode(bitand(o.flags, 1073741824), 0, 'N', 1073741824, 'Y', 'N'),
       -- CREATED_APPID
       o.CREAPPID,
       -- CREATED_VSNID
       o.CREVERID,
       -- MODIFIED_APPID,
       o.MODAPPID,
       -- MODIFIED_VSNID,
       o.MODVERID
from sys."_CURRENT_EDITION_OBJ" o, sys.user$ u
where o.owner# = u.user#
  and o.linkname is null
  and (o.type# not in (1  /* INDEX - handled below */
                       , 10 /* NON-EXISTENT */)
       or
       (o.type# = 1 and 1 = (select 1
                             from sys.ind$ i
                            where i.obj# = o.obj#
                              and i.type# in (1, 2, 3, 4, 6, 7, 9))))
  and o.name != '_NEXT_OBJECT'
  and o.name != '_default_auditing_options_'
  and bitand(o.flags, 128) = 0
  -- Exclude XML Token set objects */
  and (o.type# not in (1 /* INDEXES */,
                       2 /* TABLES */,
                       6 /* SEQUENCE */)
      or
      (o.type# = 1 and not exists (select 1
                from sys.ind$ i, sys.tab$ t, sys.obj$ io
                where i.obj# = o.obj#
                  and io.obj# = i.bo#
                  and io.type# = 2
                  and i.bo# = t.obj#
                  and bitand(t.property, power(2,65)) =  power(2,65)))
      or
      (o.type# = 2 and 1 = (select 1
                from sys.tab$ t
                where t.obj# = o.obj#
                  and (bitand(t.property, power(2,65)) = 0
                         or t.property is null)))
      or
      (o.type# = 6 and 1 = (select 1
                from sys.seq$ s
                where s.obj# = o.obj#
                  and (bitand(s.flags, 1024) = 0 or s.flags is null))))
  and
  (
    o.owner# in (userenv('SCHEMAID'), 1 /* PUBLIC */)
    or
    (
      /* non-procedural objects */
      o.type# not in (7, 8, 9, 11, 12, 13, 14, 28, 29, 30, 56, 93)
      and
      o.obj# in (select obj# from sys.objauth$
                 where grantee# in (select kzsrorol from x$kzsro)
                   and privilege# in (3 /* DELETE */,   6 /* INSERT */,
                                      7 /* LOCK */,     9 /* SELECT */,
                                      10 /* UPDATE */, 12 /* EXECUTE */,
                                      11 /* USAGE */,  16 /* CREATE */,
                                      17 /* READ */,   18 /* WRITE  */ ))
    )
    or
    (
       o.type# in (7, 8, 9, 28, 29, 30, 56) /* prc, fcn, pkg */
       and
       (
         exists (select null from sys.objauth$ oa
                  where oa.obj# = o.obj#
                    and oa.grantee# in (select kzsrorol from x$kzsro)
                    and oa.privilege# in (12 /* EXECUTE */, 26 /* DEBUG */))
        or /* user has system privileges */
         ora_check_sys_privilege ( o.owner#, o.type#) = 1
       )
    )
    or
    (
       o.type# in (19) /* partitioned table objects */
       and
       (
       exists (select bo# from tabpart$ where obj# = o.obj# and
               bo# in  (select obj# from sys.objauth$
                        where grantee# in (select kzsrorol from x$kzsro)
                        and privilege# in (9 /* SELECT */, 17 /* READ */))
              )
       or
       exists (select bo# from tabcompart$ where obj# = o.obj# and
               bo# in  (select obj# from sys.objauth$
                        where grantee# in (select kzsrorol from x$kzsro)
                        and privilege# in (9 /* SELECT */, 17 /* READ */))
               )
       )
    )
    or
    (
       o.type# in (34) /* sub-partitioned table objects */
       and
       exists (select cp.bo# from tabsubpart$ sp, tabcompart$ cp
               where sp.obj# = o.obj# and sp.pobj# = cp.obj# and
                     cp.bo# in  (select obj# from sys.objauth$
                     where  grantee# in (select kzsrorol from x$kzsro)
                     and privilege# in (9 /* SELECT */, 17 /* READ */))
              )
    )
    or
    (
       o.type# in (12) /* trigger */
       and
       (
         exists (select null from sys.trigger$ t, sys.objauth$ oa
                  where bitand(t.property, 24) = 0
                    and t.obj# = o.obj#
                    and oa.obj# = t.baseobject
                    and oa.grantee# in (select kzsrorol from x$kzsro)
                    and oa.privilege# = 26 /* DEBUG */)
         or /* user has system privileges */
         ora_check_sys_privilege (o.owner#, o.type#) = 1
       )
    )
    or
    (
       o.type# = 11 /* pkg body */
       and
       (
         exists (select null
                   from sys."_ACTUAL_EDITION_OBJ" specobj, sys.dependency$ dep,
                        sys.objauth$ oa
                  where specobj.owner# = o.owner#
                    and specobj.name = o.name
                    and specobj.type# = 9 /* pkg */
                    and dep.d_obj# = o.obj# and dep.p_obj# = specobj.obj#
                    and oa.obj# = specobj.obj#
                    and oa.grantee# in (select kzsrorol from x$kzsro)
                    and oa.privilege# = 26 /* DEBUG */)
         or /* user has system privileges */
         ora_check_sys_privilege (o.owner#, o.type#) = 1
       )
    )
    or
    (
       o.type# in (1) /* index */
       and
       exists (select i.obj# from ind$ i
               where i.obj# = o.obj#
                 and exists (select null from sys.objauth$ oa
                             where oa.obj# = i.bo#
                               and oa.grantee# in (select kzsrorol
                                                   from x$kzsro)
                            )
              )
    )
    or
    ( o.type# = 13 /* type */
      and
      (
        exists (select null from sys.objauth$ oa
                 where oa.obj# = o.obj#
                   and oa.grantee# in (select kzsrorol from x$kzsro)
                   and oa.privilege# in (12 /* EXECUTE */, 26 /* DEBUG */))
        or /* user has system privileges */
         ora_check_sys_privilege ( o.owner#, o.type#) = 1
      )
    )
    or
    (
      o.type# = 14 /* type body */
      and
      (
        exists (select null
                  from sys."_ACTUAL_EDITION_OBJ" specobj, sys.dependency$ dep,
                       sys.objauth$ oa
                 where specobj.owner# = o.owner#
                   and specobj.name = o.name
                   and specobj.type# = 13 /* type */
                   and dep.d_obj# = o.obj# and dep.p_obj# = specobj.obj#
                   and oa.obj# = specobj.obj#
                   and oa.grantee# in (select kzsrorol from x$kzsro)
                   and oa.privilege# = 26 /* DEBUG */)
        or /* user has system privileges */
         ora_check_sys_privilege ( o.owner#, o.type#) = 1
      )
    )
    or
    (
       o.type# in
       (
        1, /* index */
        2, /* table */
        3, /* view */
        4, /* synonym */
        5, /* table partn */
        6, /* sequence */
        19, /* index partn */
        20, /* table subpartn */
        22, /* library */
        23, /* directory */
        32, /* indextype */
        33, /* operator */
        34, /* index subpartn */
        35, /* cluster */
        42, /* summary */
        44, /* context */
        46, /* rule set */
        48, /* resource consumer group */
        59, /* rule */
        62, /* evaluation context */
        66, /* scheduler job */
        67, /* scheduler program */
        68, /* scheduler job class */
        79, /* scheduler chain */
        81, /* file group */
        82, /* mining model */
        87, /* assembly */
        92, /* cube dimension */
        94, /* measure folder */
        95, /* cube build process */
        100 /* file watcher */
       )
       and
          /* user has system privileges */
       ora_check_sys_privilege (o.owner#, o.type#) = 1
    )
    or
    (
      o.type# = 55 /* XML schema */
      and
      1 = (select /*+ NO_MERGE */ xml_schema_name_present.is_schema_present(o.name, u2.id2) id1 from (select /*+ NO_MERGE */ userenv('SCHEMAID') id2 from dual) u2)
      /* we need a sub-query instead of the directy invoking
       * xml_schema_name_present, because inside a view even the function
       * arguments are evaluated as definers rights.
       */
    )
    or
    (
     /* scheduler windows, scheduler groups, schedules and destinations */
     /* no privileges are needed to view these objects */
     o.type# in (69, 72, 74, 101)
    )
    or
    (
     o.type# = 57 /* edition */
    )
    or
    (
      o.type# = 93 /* cube */
      and
      (o.obj# in
            ( select obj#  /* directly granted privileges */
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or
       (
        /* user has system privileges */
        ora_check_sys_privilege ( o.owner#, o.type#) = 1
       )
      )
      and  /* require access to all Dimensions of the Cube */
      ( 1 = ( SELECT decode(have_all_dim_access, null, 1, have_all_dim_access)
              FROM
                ( SELECT
                    obj#,
                    MIN(have_dim_access) have_all_dim_access
                  FROM
                    ( SELECT
                        c.obj# obj#,
                        ( CASE
                          WHEN
                            ( do.owner# in ( userenv('SCHEMAID'), 1 )  /* public objects */
                              or do.obj# in
                              ( select obj#  /* directly granted privileges */
                                from sys.objauth$
                                where grantee# in ( select kzsrorol from x$kzsro )
                              )
                              or  /* user has system privileges */
                              ora_check_sys_privilege ( do.owner#, do.type#) = 1
                            )
                          THEN 1
                          ELSE 0
                          END ) have_dim_access
                      FROM
                        olap_cubes$ c,
                        dependency$ d,
                        obj$ do
                      WHERE
                        do.obj# = d.p_obj#
                        AND do.type# = 92 /* CUBE DIMENSION */
                        AND c.obj# = d.d_obj#
                    )
                  GROUP BY obj# ) da
              WHERE
                o.obj#=da.obj#(+)
            )
      )
    )
    or
    (
       o.type# = 114 /* sql translation profile */
       and
       (
         exists (select null from sys.objauth$ oa
                  where oa.obj# = o.obj#
                    and oa.grantee# in (select kzsrorol from x$kzsro)
                    and oa.privilege# in (0 /* ALTER */, 29 /* USE */))
         or
         /* user has system privileges */
         ora_check_sys_privilege ( o.owner#, o.type#) = 1
       )
    )
    or
    (
       o.type# in (
                   150, /* hierarchy */
                   151, /* attribute dimension */
                   152  /* analytic view */
                  )
       and ora_check_sys_privilege(o.owner#, o.type#) = 1
    )
  )
