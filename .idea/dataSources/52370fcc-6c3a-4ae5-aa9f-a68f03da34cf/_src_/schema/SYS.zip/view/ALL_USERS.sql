create view ALL_USERS as
select u.name, u.user#, u.ctime,
       decode(bitand(u.spare1, 4224), 0, 'NO', 'YES'),
       decode(bitand(u.spare1, 256), 256, 'Y', 'N'),
       decode(bitand(u.spare1, 4224),
              128, decode(SYS_CONTEXT('USERENV', 'CON_ID'), 1, 'NO', 'YES'),
              4224, decode(SYS_CONTEXT('USERENV', 'IS_APPLICATION_PDB'),
                           'YES', 'YES', 'NO'),
              'NO'),
       nls_collation_name(nvl(u.spare3, 16382)),
       -- IMPLICIT
       decode(bitand(u.spare1, 32768), 32768, 'YES', 'NO'),
       -- ALL_SHARD
       decode(bitand(u.spare1, 16384), 16384, 'YES', 'NO')
from sys.user$ u
where u.type# = 1
