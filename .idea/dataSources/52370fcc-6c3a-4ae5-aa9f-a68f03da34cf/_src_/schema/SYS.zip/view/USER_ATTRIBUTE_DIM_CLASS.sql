create view USER_ATTRIBUTE_DIM_CLASS as
select dimension_name, classification, value, language, order_num,
       origin_con_id
from  NO_ROOT_SW_FOR_LOCAL(INT$DBA_ATTR_DIM_CLASS)
where owner = sys_context('USERENV','CURRENT_USER')
