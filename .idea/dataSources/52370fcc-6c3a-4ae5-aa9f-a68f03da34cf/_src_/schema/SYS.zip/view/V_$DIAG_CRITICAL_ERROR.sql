create view V_$DIAG_CRITICAL_ERROR as
select "FACILITY","ERROR","CON_ID" from v$diag_critical_error
