create view GV_$LOADPSTAT as
select "INST_ID","OWNER","TABNAME","PARTNAME","LOADED","CON_ID" from gv$loadpstat
