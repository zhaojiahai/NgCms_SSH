create view ALL_OPERATORS as
select c.name, b.name, a.numbind from
  sys.operator$ a, sys.obj$ b, sys.user$ c where
  a.obj# = b.obj# and b.owner# = c.user# and
  ( b.owner# = userenv ('SCHEMAID')
    or
    b.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or
          ora_check_sys_privilege (b.owner#, b.type#) = 1
      )
