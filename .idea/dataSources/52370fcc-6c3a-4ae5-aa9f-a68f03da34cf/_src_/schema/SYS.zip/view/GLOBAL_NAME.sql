create view GLOBAL_NAME as
select value$ from sys.props$ where name = 'GLOBAL_DB_NAME'
