create view GV_$QUEUEING_MTH as
select "INST_ID","NAME","CON_ID" from gv$queueing_mth
