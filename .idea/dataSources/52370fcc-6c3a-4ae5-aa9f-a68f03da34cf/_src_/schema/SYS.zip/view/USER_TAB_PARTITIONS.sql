create view USER_TAB_PARTITIONS as
select o.name, 'NO', o.subname, 0,
       tp.hiboundval, tp.hiboundlen,
       row_number() over (partition by o.name order by tp.part#),
       ts.name, tp.pctfree$,
       decode(bitand(ts.flags, 32), 32, to_number(NULL), tp.pctused$),
       tp.initrans, tp.maxtrans,
       decode(bitand(tp.flags, 65536), 65536,
              ds.initial_stg * ts.blocksize, s.iniexts * ts.blocksize),
       decode(bitand(tp.flags, 65536), 65536,
              ds.next_stg * ts.blocksize, s.extsize * ts.blocksize),
       decode(bitand(tp.flags, 65536), 65536, ds.minext_stg, s.minexts),
       decode(bitand(tp.flags, 65536), 65536, ds.maxext_stg, s.maxexts),
       decode(bitand(tp.flags, 65536), 65536,
              ds.maxsiz_stg * ts.blocksize,
              decode(bitand(s.spare1, 4194304), 4194304, bitmapranges, NULL)),
       decode(bitand(ts.flags, 3), 1, to_number(NULL),
              decode(bitand(tp.flags, 65536), 65536, ds.pctinc_stg, s.extpct)),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
              decode(bitand(tp.flags, 65536), 65536,
                     decode(ds.frlins_stg, 0, 1, ds.frlins_stg),
                     decode(s.lists, 0, 1, s.lists))),
       decode(bitand(ts.flags, 32), 32, to_number(NULL),
              decode(bitand(tp.flags, 65536), 65536,
                     decode(ds.maxins_stg, 0, 1, ds.maxins_stg),
                     decode(s.groups, 0, 1, s.groups))),
       decode(mod(trunc(tp.flags / 4), 2), 0, 'YES', 'NO'),
       case when (bitand(tp.flags, 65536) = 65536) then
         decode(bitand(ds.flags_stg, 4), 4, 'ENABLED', 'DISABLED')
       else
         decode(bitand(s.spare1, 2048), 2048, 'ENABLED', 'DISABLED')
       end,
       case when (bitand(tp.flags, 65536) = 65536) then
          decode(bitand(ds.flags_stg, 4), 4,
          case when bitand(ds.cmpflag_stg, 3) = 1 then 'BASIC'
               when bitand(ds.cmpflag_stg, 3) = 2 then 'ADVANCED'
               else concat(decode(ds.cmplvl_stg, 1, 'QUERY LOW',
                                                 2, 'QUERY HIGH',
                                                 3, 'ARCHIVE LOW',
                                                    'ARCHIVE HIGH'),
                           decode(bitand(ds.flags_stg, 524288), 524288,
                                  ' ROW LEVEL LOCKING', '')) end,
           null)
       else
         decode(bitand(s.spare1, 2048), 0, null,
           case when bitand(s.spare1, 16777216) = 16777216
                     then 'ADVANCED'
                when bitand(s.spare1, 100663296) = 33554432  -- 0x2000000
                     then concat('QUERY LOW',
                                 decode(bitand(s.spare1, 2147483648),
                                        2147483648, ' ROW LEVEL LOCKING', ''))
                when bitand(s.spare1, 100663296) = 67108864  -- 0x4000000
                     then concat('QUERY HIGH',
                                 decode(bitand(s.spare1, 2147483648),
                                        2147483648, ' ROW LEVEL LOCKING', ''))
                when bitand(s.spare1, 100663296) = 100663296 -- 0x2000000+0x4000000
                     then concat('ARCHIVE LOW',
                                 decode(bitand(s.spare1, 2147483648),
                                        2147483648, ' ROW LEVEL LOCKING', ''))
                when bitand(s.spare1, 134217728) = 134217728 -- 0x8000000
                     then concat('ARCHIVE HIGH',
                                 decode(bitand(s.spare1, 2147483648),
                                        2147483648, ' ROW LEVEL LOCKING', ''))
                else 'BASIC' end)
       end,
       tp.rowcnt, tp.blkcnt, tp.empcnt, tp.avgspc, tp.chncnt, tp.avgrln,
       tp.samplesize, tp.analyzetime,
       decode(bitand(decode(bitand(tp.flags, 65536), 65536, ds.bfp_stg, s.cachehint), 3),
              1, 'KEEP', 2, 'RECYCLE', 'DEFAULT'),
       decode(bitand(decode(bitand(tp.flags, 65536), 65536, ds.bfp_stg, s.cachehint), 12)/4,
              1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(decode(bitand(tp.flags, 65536), 65536, ds.bfp_stg, s.cachehint), 48)/16,
              1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(tp.flags, 16), 0, 'NO', 'YES'),
       decode(bitand(tp.flags, 8), 0, 'NO', 'YES'),
       decode(bitand(o.flags, 16384), 0, 'NO', 'YES'),
       case bitand(o.flags, 16384)   --is the object a nested table partition?
       when  16384 then
       (select o1.subname
        from obj$ o1
        where o1.obj#=
        (select tp1.obj#
         from tabpartv$ tp1, tabpartv$ tp2, ntab$ nt
         where tp2.bo# = tp.bo#
         and tp2.obj# = tp.obj#
         and tp1.part# = tp2.part#
         and tp1.bo#=nt.obj#
         and nt.ntab#=tp.bo#))
       else
         null
       end,
       decode(bitand(tp.flags, 32768), 32768, 'YES', 'NO'),
       decode(bitand(tp.flags, 65536), 65536, 'NO', 'YES'),
       decode(bitand(tp.flags, 2097152), 2097152, 'OFF', 'ON'),
       decode(bitand(tp.flags, 67108864), 67108864, 'YES', 'NO'),
       --INMEMORY
       case when (bitand(tp.flags, 65536) = 65536) then
          -- flags/imcflag_stg (stgdef.h)
          decode(bitand(ds.flags_stg, 6291456),
                2097152, 'ENABLED',
                4194304, 'DISABLED', 'DISABLED')
       else
          -- ktsscflg (ktscts.h)
          decode(bitand(s.spare1, 70373039144960),
                4294967296, 'ENABLED',
                70368744177664, 'DISABLED', 'DISABLED')
       end,
       -- INMEMORY_PRIORITY
       case when (bitand(tp.flags, 65536) = 65536) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 4), 4,
                decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 7936),
                256, 'NONE',
                512, 'LOW',
                1024, 'MEDIUM',
                2048, 'HIGH',
                4096, 'CRITICAL', 'UNKNOWN'), null),
                'NONE'),
                null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 34359738368), 34359738368,
                decode(bitand(s.spare1, 61572651155456),
                8796093022208, 'LOW',
                17592186044416, 'MEDIUM',
                35184372088832, 'HIGH',
                52776558133248, 'CRITICAL', 'NONE'),
                'NONE'),
                null)
       end,
       -- INMEMORY_DISTRIBUTE
       case when (bitand(tp.flags, 65536) = 65536) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 1), 1,
                       decode(bitand(ds.imcflag_stg, (16+32)),
                              16,  'BY ROWID RANGE',
                              32,  'BY PARTITION',
                              48,  'BY SUBPARTITION',
                               0,  'AUTO'),
                  null), null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
               decode(bitand(s.spare1, 8589934592), 8589934592,
                        decode(bitand(s.spare1, 206158430208),
                        68719476736,  'BY ROWID RANGE',
                        137438953472,   'BY PARTITION',
                        206158430208,  'BY SUBPARTITION',
                        0,             'AUTO'),
                        null),
                  null)
       end,
       -- INMEMORY_COMPRESSION
       case when (bitand(tp.flags, 65536) = 65536) then
        decode(bitand(ds.flags_stg, 2097152), 2097152,
               decode(bitand(ds.imcflag_stg, (2+8+64+128)),
                              2,   'NO MEMCOMPRESS',
                              8,  'FOR DML',
                              10,  'FOR QUERY LOW',
                              64, 'FOR QUERY HIGH',
                              66, 'FOR CAPACITY LOW',
                              72, 'FOR CAPACITY HIGH', 'UNKNOWN'),
                null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 841813590016),
                              17179869184,  'NO MEMCOMPRESS',
                              274877906944, 'FOR DML',
                              292057776128, 'FOR QUERY LOW',
                              549755813888, 'FOR QUERY HIGH',
                              566935683072, 'FOR CAPACITY LOW',
                              824633720832, 'FOR CAPACITY HIGH', 'UNKNOWN'),
                 null)
       end,
       -- INMEMORY_DUPLICATE
       case when (bitand(tp.flags, 65536) = 65536) then
        decode(bitand(ds.flags_stg, 2097152), 2097152,
               decode(bitand(ds.imcflag_stg, (8192+16384)),
                              8192,   'NO DUPLICATE',
                              16384,  'DUPLICATE',
                              24576,  'DUPLICATE ALL',
                              null),
                null)
       else
          decode(bitand(s.spare1, 4294967296), 4294967296,
                   decode(bitand(s.spare1, 6597069766656),
                           2199023255552, 'NO DUPLICATE',
                           4398046511104, 'DUPLICATE',
                           6597069766656, 'DUPLICATE ALL', null),
                 null)
       end,
       -- CELLMEMORY
       case when (bitand(tp.flags, 65536) = 65536) then
         -- deferred segment: stgccflags (stgdef.h)
         decode(ccflag_stg,
             8194, 'NO MEMCOMPRESS',
             8196, 'MEMCOMPRESS FOR QUERY',
             8200, 'MEMCOMPRESS FOR CAPACITY',
             16384, 'DISABLED', null)
       else
         -- created segment: ktsscflg (ktscts.h)
         decode(bitand(s.spare1, 4362862139015168),
              281474976710656, 'DISABLED',
              703687441776640, 'NO MEMCOMPRESS',
             1266637395197952, 'MEMCOMPRESS FOR QUERY',
             2392537302040576, 'MEMCOMPRESS FOR CAPACITY', null)
       end,
       -- INMEMORY_SERVICE
       case when (bitand(tp.flags, 65536) = 65536) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 32768), 32768,
                       decode(bitand(svc.svcflags, 7),
                              0, null,
                              1, 'DEFAULT',
                              2, 'NONE',
                              3, 'ALL',
                              4, 'USER_DEFINED', 'DEFAULT'), 'DEFAULT'),
                null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 9007199254740992), 9007199254740992,
                       decode(bitand(svc.svcflags, 7),
                              0, null,
                              1, 'DEFAULT',
                              2, 'NONE',
                              3, 'ALL',
                              4, 'USER_DEFINED', 'DEFAULT'), 'DEFAULT'),
                 null)
       end,
       -- INMEMORY_SERVICE_NAME
       case when (bitand(tp.flags, 65536) = 65536) then
         decode(bitand(ds.flags_stg, 2097152), 2097152,
                decode(bitand(ds.imcflag_stg, 32768), 32768,
                       svc.svcname, null),
                null)
       else
         decode(bitand(s.spare1, 4294967296), 4294967296,
                decode(bitand(s.spare1, 9007199254740992), 9007199254740992,
                       svc.svcname, null),
                null)
       end
from   obj$ o, tabpart$ tp, ts$ ts, sys.seg$ s, sys.tab$ t,
       sys.deferred_stg$ ds, sys.imsvc$ svc
where  o.obj# = tp.obj# and ts.ts# = tp.ts# and tp.obj# = ds.obj#(+) and
       tp.file#=s.file#(+) and tp.block#=s.block#(+) and tp.ts#=s.ts#(+) and
       bitand(t.property, 64) != 64 and
       bitand(tp.flags, 8388608) = 0 and   /* filter out hidden partitions */
       tp.bo# = t.obj# and bitand(t.trigflag, 1073741824) != 1073741824 and
       o.owner# = userenv('SCHEMAID')
       and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
       and o.obj# = svc.obj# (+) and svc.subpart#(+) is null
union all -- IOT PARTITIONS
select o.name, 'NO', o.subname, 0,
       tp.hiboundval, tp.hiboundlen,
       row_number() over (partition by o.name order by tp.part#), NULL,
       TO_NUMBER(NULL),TO_NUMBER(NULL),TO_NUMBER(NULL),TO_NUMBER(NULL),
       TO_NUMBER(NULL), TO_NUMBER(NULL),
       TO_NUMBER(NULL),TO_NUMBER(NULL),TO_NUMBER(NULL),TO_NUMBER(NULL),
       TO_NUMBER(NULL),TO_NUMBER(NULL),
       NULL,
       'N/A', 'N/A',
       tp.rowcnt, TO_NUMBER(NULL), TO_NUMBER(NULL), 0, tp.chncnt, tp.avgrln,
       tp.samplesize, tp.analyzetime, NULL, NULL, NULL,
       decode(bitand(tp.flags, 16), 0, 'NO', 'YES'),
       decode(bitand(tp.flags, 8), 0, 'NO', 'YES'),
       'N/A', 'N/A', 'N/A',
       decode(bitand(tp.flags, 65536), 65536, 'NO', 'YES'),
       decode(bitand(tp.flags, 2097152), 2097152, 'OFF', 'ON'),
       decode(bitand(tp.flags, 67108864), 67108864, 'YES', 'NO'),
       'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A'
from   obj$ o, tabpart$ tp, tab$ t
where  o.obj# = tp.obj# and
       tp.bo# = t.obj# and bitand(t.trigflag, 1073741824) != 1073741824 and
       bitand(t.property, 64) = 64 and
       o.owner# = userenv('SCHEMAID')
       and o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL
union all -- COMPOSITE PARTITIONS
select o.name, 'YES', o.subname, tcp.subpartcnt,
       tcp.hiboundval, tcp.hiboundlen,
       row_number() over (partition by o.name order by tcp.part#),
       ts.name, tcp.defpctfree,
       decode(bitand(ts.flags, 32), 32, to_number(NULL), tcp.defpctused),
       tcp.definitrans, tcp.defmaxtrans,
       tcp.definiexts, tcp.defextsize, tcp.defminexts, tcp.defmaxexts,
       tcp.defmaxsize, tcp.defextpct,
       decode(bitand(ts.flags, 32), 32, to_number(NULL), tcp.deflists),
       decode(bitand(ts.flags, 32), 32,  to_number(NULL),tcp.defgroups),
       decode(tcp.deflogging, 0, 'NONE', 1, 'YES', 2, 'NO', 'UNKNOWN'),
       decode(bitand(tcp.spare2, 3), 1, 'ENABLED', 2, 'DISABLED', 'NONE'),
       decode(bitand(tcp.spare2, 1), 0, null,
         case bitand(tcp.spare2, 127) -- 1st 6 bits used
         when 1 then 'BASIC'                               -- 00000001
         when 5 then 'ADVANCED'                            -- 00000101
         when 9 then 'QUERY LOW'                           -- 00001001
         when 17 then 'QUERY HIGH'                         -- 00010001
         when 25 then 'ARCHIVE LOW'                        -- 00011001
         when 33 then 'ARCHIVE HIGH'                       -- 00100001
         when 73 then 'QUERY LOW ROW LEVEL LOCKING'        -- 01001001
         when 81 then 'QUERY HIGH ROW LEVEL LOCKING'       -- 01010001
         when 89 then 'ARCHIVE LOW ROW LEVEL LOCKING'      -- 01011001
         when 97 then 'ARCHIVE HIGH ROW LEVEL LOCKING'     -- 01100001
                 else 'UNKNOWN' end),                      -- internal ilevels
       tcp.rowcnt, tcp.blkcnt, tcp.empcnt, tcp.avgspc, tcp.chncnt, tcp.avgrln,
       tcp.samplesize, tcp.analyzetime,
       decode(bitand(tcp.defbufpool, 3), 1, 'KEEP', 2, 'RECYCLE', 'DEFAULT'),
       decode(bitand(tcp.defbufpool, 12)/4, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(tcp.defbufpool, 48)/16, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(bitand(tcp.flags, 16), 0, 'NO', 'YES'),
       decode(bitand(tcp.flags, 8), 0, 'NO', 'YES'),
       'N/A', 'N/A',
       decode(bitand(tcp.flags, 32768), 32768, 'YES', 'NO'),
       decode(bitand(tcp.spare2, 768), 256, 'NO', 512, 'YES', 'NONE'),
       decode(bitand(tcp.spare2, 3072), 1024, 'ON', 2048, 'OFF', 'NONE'),
       decode(bitand(tcp.spare2, 12288), 4096, 'YES',8192, 'NO', 'NONE'),
       -- INMEMORY
       -- defimcflags_kkpacpcd
       decode(bitand(tcp.spare2, 196608),
              0,      'NONE',
              65536,  'ENABLED',
              131072, 'DISABLED', 'UNKNOWN'),
       -- INMEMORY_PRIORITY
       case bitand(mod(trunc(tcp.spare2/65536),4096), 17) -- bits 0,4
         when 0 then NULL
         when 1 then
           case bitand(mod(trunc(tcp.spare2/268435456),16), 7)
             when 0 then 'NONE'
             else NULL end
         when 17 then
           case bitand(mod(trunc(tcp.spare2/268435456),16), 7)
             when 0 then 'NONE'
             when 1 then 'LOW'
             when 2 then 'MEDIUM'
             when 3 then 'HIGH'
             when 4 then 'CRITICAL'
             else 'UNKNOWN' end
         else 'UNKNOWN' end,
       -- INMEMORY_DISTRIBUTE
       decode(bitand(tcp.spare2, 65536), 65536,
              decode(bitand(tcp.spare2, 262144), 262144,
                     decode(bitand(tcp.spare2, (2097152+4194304)),
                     0,         'AUTO',
                     2097152,   'BY ROWID RANGE',
                     4194304,   'BY PARTITION',
                     6291456,   'BY SUBPARTITION'),
              null), null),
       -- INMEMORY_COMPRESSION
       decode(bitand(tcp.spare2, 65536), 65536,
              decode(bitand(tcp.spare2, (524288+8388608+16777216)),
                              524288,             'NO MEMCOMPRESS',
                              8388608,            'FOR DML',
                              (524288+8388608),   'FOR QUERY LOW',
                              16777216,           'FOR QUERY HIGH',
                              (524288+16777216),  'FOR CAPACITY LOW',
                              (8388608+16777216), 'FOR CAPACITY HIGH',
                     null),
              null),
       -- INMEMORY_DUPLICATE
       decode (bitand(tcp.spare2, 65536), 65536,
               decode(bitand(tcp.spare2, (67108864+134217728)),
                              67108864,   'NO DUPLICATE',
                              134217728,  'DUPLICATE',
                              (67108864+134217728),  'DUPLICATE ALL',
                              null),
                null),
       -- CELLMEMORY
       decode(bitand(tcp.spare2, 133143986176),
              8589934592,  'DISABLED',
              21474836480, 'NO MEMCOMPRESS',
              38654705664, 'MEMCOMPRESS FOR QUERY',
              73014444032, 'MEMCOMPRESS FOR CAPACITY',
              NULL),
       -- INMEMORY_SERVICE
       decode(bitand(tcp.spare2, 65536), 65536,
              decode(bitand(tcp.spare2, 1099511627776), 1099511627776,
                     decode(bitand(svc.svcflags, 7),
                            0, null,
                            1, 'DEFAULT',
                            2, 'NONE',
                            3, 'ALL',
                            4, 'USER_DEFINED',
                            'DEFAULT'),
                     null),
              null),
       -- INMEMORY_SERVICE_NAME
       decode(bitand(tcp.spare2, 65536), 65536,
              decode(bitand(tcp.spare2, 1099511627776), 1099511627776,
                     svc.svcname, null),
              null)
from   obj$ o, tabcompart$ tcp, ts$ ts, tab$ t, imsvc$ svc
where  o.obj# = tcp.obj# and tcp.defts# = ts.ts# and
       o.owner# = userenv('SCHEMAID') and
       bitand(t.property, 64) != 64 and
       bitand(tcp.flags, 8388608) = 0 and   /* filter out hidden partitions */
       o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL and
       tcp.bo# = t.obj# and
       (bitand(t.trigflag, 1073741824) != 1073741824) and
       o.obj# = svc.obj# (+) and svc.subpart#(+) is null
