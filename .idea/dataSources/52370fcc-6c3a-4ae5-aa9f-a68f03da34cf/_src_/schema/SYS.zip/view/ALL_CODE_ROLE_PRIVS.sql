create view ALL_CODE_ROLE_PRIVS as
(
select u.name, o.name, decode(o.type#, 7,  'PROCEDURE',
                               8,  'FUNCTION',
                               9,  'PACKAGE',
                               13, 'TYPE',
                                   'UNDEFINED'),
       r.name
  from sys."_CURRENT_EDITION_OBJ" o, sys.user$ u, sys.user$ r,
       sys.codeauth$ c
 where o.obj# = c.obj#
   and c.privilege# = r.user#
   and u.user# = o.owner#
   and (o.owner# = userenv('SCHEMAID')
    or
    (
      o.obj# in (select obj# from sys.objauth$
                 where grantee# in (select kzsrorol from x$kzsro)
                 and privilege# in (3 /* DELETE */,   6 /* INSERT */,
                                    7 /* LOCK */,     9 /* SELECT */,
                                    10 /* UPDATE */, 12 /* EXECUTE */,
                                    11 /* USAGE */,  16 /* CREATE */,
                                    17 /* READ */,   18 /* WRITE  */))
    )
    or
      ora_check_sys_privilege (o.owner#, o.type#) = 1
  )
)
