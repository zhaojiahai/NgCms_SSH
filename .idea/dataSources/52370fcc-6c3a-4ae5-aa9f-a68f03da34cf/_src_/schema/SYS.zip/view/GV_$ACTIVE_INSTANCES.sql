create view GV_$ACTIVE_INSTANCES as
select "INST_ID","INST_NUMBER","INST_NAME","CON_ID" from gv$active_instances
