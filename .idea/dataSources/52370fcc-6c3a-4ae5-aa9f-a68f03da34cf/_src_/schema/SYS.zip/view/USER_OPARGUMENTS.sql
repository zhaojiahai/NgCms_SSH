create view USER_OPARGUMENTS as
select  c.name, b.name, a.bind#, a.position, a.type
  from  sys.oparg$ a, sys.obj$ b, sys.user$ c
  where a.obj# = b.obj# and b.owner# = c.user#
  and   b.owner# = userenv ('SCHEMAID')
