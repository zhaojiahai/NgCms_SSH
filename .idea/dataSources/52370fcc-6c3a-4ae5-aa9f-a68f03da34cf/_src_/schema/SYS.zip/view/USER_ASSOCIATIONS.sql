create view USER_ASSOCIATIONS as
select u.name, o.name, c.name,
         decode(a.property, 1, 'COLUMN', 2, 'TYPE', 3, 'PACKAGE', 4,
                'FUNCTION', 5, 'INDEX', 6, 'INDEXTYPE', 'INVALID'),
         u1.name, o1.name,a.default_selectivity,
         a.default_cpu_cost, a.default_io_cost, a.default_net_cost,
         a.interface_version#,
         decode (bitand(a.spare2, 1), 1, 'SYSTEM_MANAGED', 'USER_MANAGED')
   from  sys.association$ a, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u,
         sys."_CURRENT_EDITION_OBJ" o1, sys.user$ u1, sys.col$ c
   where a.obj#=o.obj# and o.owner#=u.user#
   AND   a.statstype#=o1.obj# (+) and o1.owner#=u1.user# (+)
   AND   a.obj# = c.obj#  (+)  and a.intcol# = c.intcol# (+)
   and o.owner#=userenv('SCHEMAID')
