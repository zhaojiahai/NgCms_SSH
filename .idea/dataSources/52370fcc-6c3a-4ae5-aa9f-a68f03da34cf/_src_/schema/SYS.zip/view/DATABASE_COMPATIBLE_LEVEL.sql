create view DATABASE_COMPATIBLE_LEVEL as
select value,description
from v$parameter
where name = 'compatible'
