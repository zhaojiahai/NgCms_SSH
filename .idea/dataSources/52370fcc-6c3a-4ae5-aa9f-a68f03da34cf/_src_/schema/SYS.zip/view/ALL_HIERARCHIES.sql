create view ALL_HIERARCHIES as
select OWNER,
       HIER_NAME,
       DIMENSION_OWNER,
       DIMENSION_NAME,
       --da.attr_name PARENT_ATTR,
       PARENT_ATTR,
       COMPILE_STATE,
     --DECODE(h.val_state, 1, 'VALID', 2, 'NEEDS_VALIDATE', 3, 'ERROR') VALID_STATE,
     origin_con_id
from INT$DBA_HIERARCHIES
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, HIER_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
