create view USER_XTERNAL_LOC_SUBPARTITIONS as
select po.name, po.subname, so.subname, xl.name, 'SYS', nvl(xl.dir, xt.default_dir)
from sys.external_location$ xl, sys.external_tab$ xt, sys.obj$ so, sys.obj$ po,
     sys.tabcompart$ tcp, sys.tabsubpart$ tsp, sys.tab$ t
where so.obj# = xl.obj# and
      so.obj# = xt.obj# and
      so.obj# = tsp.obj# and
      po.obj# = tsp.pobj# and
      tcp.obj# = tsp.pobj# and
      tcp.bo# = t.obj# and
      po.owner# = userenv('SCHEMAID') and
      so.owner# = userenv('SCHEMAID') and
      po.namespace = 1 and
      po.remoteowner IS NULL and
      po.linkname IS NULL and
      so.namespace = 1 and
      so.remoteowner IS NULL and
      so.linkname IS NULL
