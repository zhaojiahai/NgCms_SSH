create view LOADER_FULL_ATTR_NAME as
select a.name as full_attr_name, c.name as intcol_name,
               u.name as table_owner,    o.name as table_name
        from sys.col$ c, sys.obj$ o, sys.user$ u, sys.attrcol$ a
        where o.obj# = c.obj# and o.owner# = u.user# and
              c.obj# = a.obj# and c.intcol# = a.intcol#
              and (o.owner# = userenv('schemaid')
                    or o.obj# in
                         (select oa.obj#
                          from sys.objauth$ oa
                          where grantee# in ( select kzsrorol
                                              from x$kzsro
                                            )
                         )
                    or
                      ora_check_SYS_privilege (o.owner#, o.type#) = 1
                   )
