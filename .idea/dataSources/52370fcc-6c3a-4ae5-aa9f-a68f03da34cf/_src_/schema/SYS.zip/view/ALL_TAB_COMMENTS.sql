create view ALL_TAB_COMMENTS as
select OWNER, TABLE_NAME, TABLE_TYPE, COMMENTS, ORIGIN_CON_ID
from INT$DBA_TAB_COMMENTS
where (OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
        or
        OBJ_ID(OWNER, TABLE_NAME, OBJECT_TYPE#, OBJECT_ID)
        in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                         from x$kzsro
                                       )
                  )
        or /* user has system privileges */
           /* 2 is the type# for Table. See kgl.h for more info */
        ora_check_sys_privilege (ownerid, 2 ) = 1
       )
