create view USER_SUBPART_KEY_COLUMNS as
select
  NAME, OBJECT_TYPE, COLUMN_NAME, COLUMN_POSITION, COLLATED_COLUMN_ID
from user_subpart_key_columns_v$
