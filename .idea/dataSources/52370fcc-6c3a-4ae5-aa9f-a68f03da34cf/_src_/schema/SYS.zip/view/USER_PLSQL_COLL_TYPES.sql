create view USER_PLSQL_COLL_TYPES as
select c.coll_name,
       o.name,
       decode(bitand(c.properties, 2097152), 2097152, 'PL/SQL INDEX TABLE',
              decode(bitand(c.properties, 4194304), 4194304,
                     'PL/SQL INDEX TABLE', co.name)),
       c.upper_bound,
       nvl2(c.synobj#, (select u.name from user$ u, "_CURRENT_EDITION_OBJ" o
            where o.owner#=u.user# and o.obj#=c.synobj#),
            decode(bitand(et.properties, 64), 64, null, eu.name)),
       nvl2(c.synobj#, (select o.name from "_CURRENT_EDITION_OBJ" o
                        where o.obj#=c.synobj#),
            decode(et.typecode,
                   9, decode(c.charsetform, 2, 'NVARCHAR2', eo.name),
                   96, decode(c.charsetform, 2, 'NCHAR', eo.name),
                   112, decode(c.charsetform, 2, 'NCLOB', eo.name),
                   eo.name)),
       null,
       c.length,
       c.precision,
       c.scale,
       decode(c.charsetform, 1, 'CHAR_CS',
                             2, 'NCHAR_CS',
                             3, NLS_CHARSET_NAME(c.charsetid),
                             4, 'ARG:'||c.charsetid),
       decode(bitand(c.properties, 131072), 131072, 'FIXED',
              decode(bitand(c.properties, 262144), 262144, 'VARYING')),
       decode(bitand(c.properties, 65536), 65536, 'NO', 'YES'),
       decode(bitand(c.properties, 2097152), 2097152, 'BINARY_INTEGER',
              decode(bitand(c.properties, 4194304), 4194304, 'VARCHAR2')),
       decode(bitand(c.properties, 32768), 32768, 'REF',
              decode(bitand(c.properties, 16384), 16384, 'POINTER'))
from sys."_CURRENT_EDITION_OBJ" o, sys.collection$ c,
     sys."_CURRENT_EDITION_OBJ" co,
     sys."_CURRENT_EDITION_OBJ" eo, sys.user$ eu, sys.type$ et
where o.owner# = userenv('SCHEMAID')
  and c.package_obj# IS NOT NULL                          -- only package types
  and o.obj# = c.package_obj#
  and o.subname IS NULL -- only the most recent version
  and o.type# <> 10 -- must not be invalid
  and c.coll_toid = co.oid$
  and c.elem_toid = eo.oid$
  and eo.owner# = eu.user#
  and c.elem_toid = et.tvoid
UNION
--
-- Package collection types with package level element types
--
select c.coll_name,
       o.name,
       decode(bitand(c.properties, 2097152), 2097152, 'PL/SQL INDEX TABLE',
              decode(bitand(c.properties, 4194304), 4194304,
                     'PL/SQL INDEX TABLE', co.name)),
       c.upper_bound,
       nvl2(c.synobj#, (select u.name from user$ u, "_CURRENT_EDITION_OBJ" o
            where o.owner#=u.user# and o.obj#=c.synobj#),
            decode(bitand(et.properties, 64), 64, null, eu.name)),
       et.typ_name ||  decode(bitand(et.properties,134217728),134217728,
                                     '%ROWTYPE', null),
       nvl2(c.synobj#, (select o.name
                        from "_CURRENT_EDITION_OBJ" o
                        where o.obj#=c.synobj#),
            decode(et.typecode,
                   9, decode(c.charsetform, 2, 'NVARCHAR2', eo.name),
                   96, decode(c.charsetform, 2, 'NCHAR', eo.name),
                   112, decode(c.charsetform, 2, 'NCLOB', eo.name),
                   eo.name)),
       c.length,
       c.precision,
       c.scale,
       decode(c.charsetform, 1, 'CHAR_CS',
                             2, 'NCHAR_CS',
                             3, NLS_CHARSET_NAME(c.charsetid),
                             4, 'ARG:'||c.charsetid),
       decode(bitand(c.properties, 131072), 131072, 'FIXED',
              decode(bitand(c.properties, 262144), 262144, 'VARYING')),
       decode(bitand(c.properties, 65536), 65536, 'NO', 'YES'),
       decode(bitand(c.properties, 2097152), 2097152, 'BINARY_INTEGER',
              decode(bitand(c.properties, 4194304), 4194304, 'VARCHAR2')),
       null
from sys."_CURRENT_EDITION_OBJ" o, sys.collection$ c,
     sys."_CURRENT_EDITION_OBJ" co,
     sys."_CURRENT_EDITION_OBJ" eo, sys.user$ eu, sys.type$ et
where o.owner# = userenv('SCHEMAID')
  and c.package_obj# IS NOT NULL                          -- only package types
  and o.obj# = c.package_obj#
  and o.type# <> 10 -- must not be invalid
  and c.coll_toid = co.oid$
  and et.package_obj# IS NOT NULL
  and et.package_obj# = eo.obj#
  and eo.owner# = eu.user#
  and c.elem_toid = et.toid
UNION
--
-- Package collection types with rowtype elements
--
select c.coll_name,
       o.name,
       decode(bitand(c.properties, 2097152), 2097152, 'PL/SQL INDEX TABLE',
              decode(bitand(c.properties, 4194304), 4194304,
                     'PL/SQL INDEX TABLE', co.name)),
       c.upper_bound,
       nvl2(c.synobj#, (select u.name                          /* Type Owner */
                        from user$ u, "_CURRENT_EDITION_OBJ" o
                        where o.owner#=u.user# and o.obj#=c.synobj#),
            eu.name),
       nvl2(c.synobj#, (select o.name                           /* Type Name */
                        from "_CURRENT_EDITION_OBJ" o
                        where o.obj#=c.synobj#),
            eo.name) || '%ROWTYPE',
       null,                                                 /* Package Name */
       null, null, null, null,
       decode(bitand(c.properties, 131072), 131072, 'FIXED',
              decode(bitand(c.properties, 262144), 262144, 'VARYING')),
       decode(bitand(c.properties, 65536), 65536, 'NO', 'YES'),
       decode(bitand(c.properties, 2097152), 2097152, 'BINARY_INTEGER',
              decode(bitand(c.properties, 4194304), 4194304, 'VARCHAR2')),
       decode(bitand(c.properties, 32768), 32768, 'REF',
              decode(bitand(c.properties, 16384), 16384, 'POINTER'))
from sys."_CURRENT_EDITION_OBJ" o, sys.collection$ c,
     sys."_CURRENT_EDITION_OBJ" co,
     sys."_CURRENT_EDITION_OBJ" eo, sys.user$ eu, sys.oid$ id
where o.owner# = userenv('SCHEMAID')
  and c.package_obj# IS NOT NULL                          -- only package types
  and o.obj# = c.package_obj#
  and o.subname IS NULL -- only the most recent version
  and o.type# <> 10 -- must not be invalid
  and c.coll_toid = co.oid$
  and c.elem_toid = id.oid$
  and id.obj# = eo.obj#
  and eo.type# in (2,4)                     -- table or view collection element
  and eo.owner# = eu.user#
