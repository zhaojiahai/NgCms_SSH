create view GV_$TIMEZONE_NAMES as
select "TZNAME","TZABBREV","CON_ID" from gv$timezone_names
