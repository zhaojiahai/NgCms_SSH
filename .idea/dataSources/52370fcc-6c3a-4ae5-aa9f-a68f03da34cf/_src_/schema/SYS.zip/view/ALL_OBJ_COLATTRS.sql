create view ALL_OBJ_COLATTRS as
select u.name, o.name, c.name,
  lpad(decode(bitand(ct.flags, 512), 512, 'Y', 'N'), 15)
from sys.coltype$ ct, sys."_CURRENT_EDITION_OBJ" o, sys.col$ c, sys.user$ u
where o.owner# = u.user#
  and bitand(ct.flags, 2) = 2                                 /* ADT column */
  and o.obj#=ct.obj#
  and o.obj#=c.obj#
  and c.intcol#=ct.intcol#
  and bitand(c.property,32768) != 32768                 /* not unused column */
  and not exists (select null                   /* Doesn't exist in attrcol$ */
                  from sys.attrcol$ ac
                  where ac.intcol#=ct.intcol#
                        and ac.obj#=ct.obj#)
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
          ora_check_sys_privilege (o.owner#, o.type#) = 1
      )
union all
select u.name, o.name, ac.name,
  lpad(decode(bitand(ct.flags, 512), 512, 'Y', 'N'), 15)
from sys.coltype$ ct, sys."_CURRENT_EDITION_OBJ" o, sys.attrcol$ ac,
     sys.user$ u, col$ c
where o.owner# = u.user#
  and bitand(ct.flags, 2) = 2                                /* ADT column */
  and o.obj#=ct.obj#
  and o.obj#=c.obj#
  and o.obj#=ac.obj#
  and c.intcol#=ct.intcol#
  and c.intcol#=ac.intcol#
  and bitand(c.property,32768) != 32768               /* not unused column */
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
          ora_check_sys_privilege (o.owner#, o.type#) = 1
      )
