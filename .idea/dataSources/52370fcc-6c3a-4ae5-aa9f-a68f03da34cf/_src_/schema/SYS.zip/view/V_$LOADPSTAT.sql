create view V_$LOADPSTAT as
select "OWNER","TABNAME","PARTNAME","LOADED","CON_ID" from v$loadpstat
