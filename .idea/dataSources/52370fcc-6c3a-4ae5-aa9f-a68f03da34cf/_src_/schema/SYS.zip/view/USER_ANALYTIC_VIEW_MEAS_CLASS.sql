create view USER_ANALYTIC_VIEW_MEAS_CLASS as
select analytic_view_name, measure_name, classification, value,
       language, order_num, origin_con_id
from NO_ROOT_SW_FOR_LOCAL(INT$DBA_AVIEW_MEAS_CLASS)
where OWNER = SYS_CONTEXT('USERENV','CURRENT_USER')
