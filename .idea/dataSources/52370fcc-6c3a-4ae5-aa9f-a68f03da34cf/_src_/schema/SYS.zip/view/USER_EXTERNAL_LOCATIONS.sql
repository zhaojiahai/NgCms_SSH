create view USER_EXTERNAL_LOCATIONS as
select o.name, xl.name, 'SYS', nvl(xl.dir, xt.default_dir)
from sys.external_location$ xl, sys.obj$ o, sys.external_tab$ xt
where o.owner# = userenv('SCHEMAID')
  and o.subname IS NULL
  and o.obj# = xl.obj#
  and o.obj# = xt.obj#
