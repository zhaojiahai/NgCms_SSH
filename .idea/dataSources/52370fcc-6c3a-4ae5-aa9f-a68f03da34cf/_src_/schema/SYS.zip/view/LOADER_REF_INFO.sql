create view LOADER_REF_INFO as
select owner, table_name, object_id_type
        from all_object_tables
