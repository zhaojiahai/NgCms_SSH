create view LOADER_COL_FLAGS as
select u.name as table_owner, o.name as table_name, c.name as colname,
         c.property as property,
         decode(bitand(c.property, 67108864), 67108864, 1, 0) as isencrypted,
         decode((bitand ((bitand(decode(bitand(c.property, 10), 10, 0, 1),
                          decode(bitand(c.property, 256), 256, 0, 1))),
                        decode(bitand(c.property, 65544), 65544, 1, 0))),
                1, 'YES', 'NO') isvirtual
    from sys.col$ c, sys.obj$ o, sys.user$ u
   where o.obj# = c.obj# and u.user# = o.owner#
   and   (o.owner# = userenv('schemaid')
    or   o.obj# in (select oa.obj#
                      from sys.objauth$ oa
                      where grantee# in ( select kzsrorol
                                          from x$kzsro
                                        )
                   )
    or
         ora_check_SYS_privilege (o.owner#, o.type#) = 1
    )
