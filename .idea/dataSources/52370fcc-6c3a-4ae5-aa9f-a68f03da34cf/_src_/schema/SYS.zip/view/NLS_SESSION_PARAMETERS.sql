create view NLS_SESSION_PARAMETERS as
select substr(parameter, 1, 30),
       substr(value, 1, 64)
from v$nls_parameters
where parameter != 'NLS_CHARACTERSET' and
 parameter != 'NLS_NCHAR_CHARACTERSET'
