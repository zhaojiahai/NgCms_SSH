create view GV_$LOCK_ACTIVITY as
select "INST_ID","FROM_VAL","TO_VAL","ACTION_VAL","COUNTER","CON_ID" from gv$lock_activity
