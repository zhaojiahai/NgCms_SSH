create view V_$LOADISTAT as
select "OWNER","TABNAME","INDEXNAME","SUBNAME","MESSAGE_NUM","MESSAGE","CON_ID" from v$loadistat
