create view LOADER_FILE_TS as
select file$.ts#, v$dbfile.name, file$.relfile#
   from file$, v$dbfile
   where file$.file# = v$dbfile.file#
