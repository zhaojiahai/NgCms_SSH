create view ALL_INDEXTYPE_OPERATORS as
select u.name, o.name, u1.name, op.name, i.bind#
from sys.user$ u, sys.indop$ i, sys.obj$ o,
sys.obj$ op, sys.user$ u1
where i.obj# = o.obj# and i.oper# = op.obj# and
      u.user# = o.owner# and bitand(i.property, 4) != 4 and u1.user#=op.owner# and
      ( o.owner# = userenv ('SCHEMAID')
      or
      o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or ora_check_sys_privilege (o.owner#, o.type#) = 1
      )
