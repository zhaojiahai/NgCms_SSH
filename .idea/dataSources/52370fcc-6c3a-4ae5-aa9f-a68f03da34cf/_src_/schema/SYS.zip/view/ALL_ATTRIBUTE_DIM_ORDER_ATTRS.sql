create view ALL_ATTRIBUTE_DIM_ORDER_ATTRS as
select OWNER, DIMENSION_NAME, LEVEL_NAME, AGG_FUNC, ATTRIBUTE_NAME,
       ORDER_NUM, CRITERIA, NULLS_POSITION, ORIGIN_CON_ID
from INT$DBA_ATTR_DIM_ORDER_ATT
where  OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, DIMENSION_NAME, OBJECT_TYPE, OBJECT_ID) in
       (select obj#
       from sys.objauth$
       where grantee# in (select kzsrorol from x$kzsro )
       )
       or /* user has sys privs */
       ora_check_sys_privilege(owner_id, object_type) = 1
