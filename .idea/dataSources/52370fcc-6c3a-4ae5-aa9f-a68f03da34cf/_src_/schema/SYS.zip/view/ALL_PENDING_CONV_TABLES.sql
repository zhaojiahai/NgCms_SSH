create view ALL_PENDING_CONV_TABLES as
select u.name, o.name
from sys.obj$ o, user$ u
  where o.type# = 2 and o.status = 5
  and bitand(o.flags, 4096) = 4096  /* type evolved flg */
  and o.owner# = u.user#
  and (o.owner# = userenv('SCHEMAID')
       or
       o.obj# in (select oa.obj#
                  from sys.objauth$ oa
                  where grantee# in (select kzsrorol
                                     from x$kzsro))
       or /* user has system privileges */
          ora_check_sys_privilege (o.owner#, o.type#) = 1
  )
