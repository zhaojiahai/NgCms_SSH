create view NLS_DATABASE_PARAMETERS as
select name,
       substr(value$, 1, 64)
from x$props
where name like 'NLS%'
