create view ALL_ANALYTIC_VIEW_LEVEL_CLASS as
select owner,
       ANALYTIC_VIEW_NAME,
       DIMENSION_ALIAS,
       HIER_ALIAS,
       LEVEL_NAME,
       CLASSIFICATION,
       VALUE,
       language,
       ORDER_NUM,
       origin_con_id
from INT$DBA_AVIEW_LEVEL_CLASS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, ANALYTIC_VIEW_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
