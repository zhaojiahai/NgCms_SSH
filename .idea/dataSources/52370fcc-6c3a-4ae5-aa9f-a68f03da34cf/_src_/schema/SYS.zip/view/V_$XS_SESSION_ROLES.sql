create view V_$XS_SESSION_ROLES as
select "ROLE_WSPACE","ROLE_NAME","FLAGS","CON_ID" from v$xs_session_role
