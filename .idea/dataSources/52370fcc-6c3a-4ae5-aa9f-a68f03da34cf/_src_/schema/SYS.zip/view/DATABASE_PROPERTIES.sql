create view DATABASE_PROPERTIES as
select name, value$, comment$
  from x$props
