create view ALL_ANALYTIC_VIEW_HIER_CLASS as
select owner,
       ANALYTIC_VIEW_NAME,
       DIMENSION_ALIAS,
       HIER_ALIAS,
       CLASSIFICATION,
       VALUE,
       language,
       ORDER_NUM,
       ORIGIN_CON_ID
from INT$DBA_AVIEW_HIER_CLASS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, ANALYTIC_VIEW_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
