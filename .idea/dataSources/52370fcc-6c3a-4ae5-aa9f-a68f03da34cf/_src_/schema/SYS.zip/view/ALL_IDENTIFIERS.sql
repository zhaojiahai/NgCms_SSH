create view ALL_IDENTIFIERS as
select OWNER, NAME, SIGNATURE, TYPE, OBJECT_NAME, OBJECT_TYPE,
       USAGE, USAGE_ID, LINE, COL, USAGE_CONTEXT_ID,
       ORIGIN_CON_ID
from INT$DBA_IDENTIFIERS
where
  (
    OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
    or OWNER = 'PUBLIC'
    or
    (
      (
         (
          (OBJECT_TYPE#
           in (7 /* proc */, 8 /* func */, 9 /* pkg */, 13 /* type */,
               22 /* library */))
          and
          OBJ_ID(OWNER, OBJECT_NAME, OBJECT_TYPE#, OBJECT_ID) in
          (select obj# from sys.objauth$
                     where grantee# in (select kzsrorol from x$kzsro)
                       and privilege# in (12 /* EXECUTE */, 26 /* DEBUG */))
        )
        or
        (
          (OBJECT_TYPE# in (2 /* table */, 4 /* view */))
          and
          OBJ_ID(OWNER, OBJECT_NAME, OBJECT_TYPE#, OBJECT_ID) in
          (select obj# from sys.objauth$
                     where grantee# in (select kzsrorol from x$kzsro)
                       and privilege# in (0 /* ALTER */, 6 /* INSERT */,
                                          9 /* SELECT */, 10 /* UPDATE */))
        )
        or
        (
          (OBJECT_TYPE# in (6 /* sequence */))
          and
          OBJ_ID(OWNER, OBJECT_NAME, OBJECT_TYPE#, OBJECT_ID) in
          (select obj# from sys.objauth$
                     where grantee# in (select kzsrorol from x$kzsro)
                       and privilege# in (0 /* ALTER */, 9 /* SELECT */))
        )
        or
        (
          (OBJECT_TYPE# in (11 /* package body */, 14 /* type body */))
          and
          exists
          (
            select null from sys.obj$ specobj, sys.objauth$ oa, sys.user$ u
            where specobj.owner# = u.user#
              and u.name = OWNER
              and specobj.name = OBJECT_NAME
              and specobj.type# = decode(OBJECT_TYPE#,
                                         11 /* pkg body */, 9 /* pkg */,
                                         14 /* type body */, 13 /* type */,
                                         null)
              and oa.obj# = specobj.obj#
              and oa.grantee# in (select kzsrorol from x$kzsro)
              and oa.privilege# = 26 /* DEBUG */)
        )
        or
        (
          (OBJECT_TYPE# = 12 /* trigger */)
          and
          exists
          (
            select null
            from sys.trigger$ t, sys.obj$ tabobj, sys.objauth$ oa, sys.user$ u
            where t.obj# = OBJ_ID(OWNER, OBJECT_NAME, 12, OBJECT_ID)
              and tabobj.obj# = t.baseobject
              and tabobj.owner# = u.user#
              and u.name = OWNER
              and oa.obj# = tabobj.obj#
              and oa.grantee# in (select kzsrorol from x$kzsro)
              and oa.privilege# = 26 /* DEBUG */)
        )
        or
        exists
        (
          select null from sys.sysauth$
          where grantee# in (select kzsrorol from x$kzsro)
          and
          (
            (
              /* procedure */
              (OBJECT_TYPE# = 7 or OBJECT_TYPE# = 8 or OBJECT_TYPE# = 9)
              and
              (
                privilege# = -144 /* EXECUTE ANY PROCEDURE */
                or
                privilege# = -141 /* CREATE ANY PROCEDURE */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
            or
            (
              /* package body */
              OBJECT_TYPE# = 11 and
              (
                privilege# = -141 /* CREATE ANY PROCEDURE */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
            or
            (
              /* type */
              OBJECT_TYPE# = 13
              and
              (
                privilege# = -184 /* EXECUTE ANY TYPE */
                or
                privilege# = -181 /* CREATE ANY TYPE */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
            or
            (
              /* type body */
              OBJECT_TYPE# = 14 and
              (
                privilege# = -181 /* CREATE ANY TYPE */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
            or
            (
              /* triggers */
              OBJECT_TYPE# = 12 and
              (
                privilege# = -152 /* CREATE ANY TRIGGER */
                or
                privilege# = -241 /* DEBUG ANY PROCEDURE */
              )
            )
            or
            (
              /* library */
              OBJECT_TYPE# = 22 and
              (
                privilege# = -189 /* CREATE ANY LIBRARY */
                or
                privilege# = -192 /* EXECUTE ANY LIBRARY */
              )
            )
          )
        )
      )
    )
  )
