create view LOADER_COL_INFO as
select o.name as tblnam,c.name as colnam,c.charsetform as csform
          from col$ c,obj$ o
         where o.obj# = c.obj#
         and o.type# = 2
         and o.owner# = SYS_CONTEXT('USERENV','CURRENT_USERID')
         and
         ( o.owner# = userenv('schemaid')
           or o.obj# in (select oa.obj#
                           from sys.objauth$ oa
                          where grantee# in (select kzsrorol from x$kzsro)
                        )
           or ora_check_SYS_privilege (o.owner#, o.type#) = 1
         )
