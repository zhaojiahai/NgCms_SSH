create view ALL_HIER_COLUMNS as
select OWNER,
       HIER_NAME,
       COLUMN_NAME,
       ROLE,
       DATA_TYPE,
       DATA_LENGTH,
       DATA_PRECISION,
       DATA_SCALE,
       NULLABLE,
       CHARACTER_SET_NAME,
       CHAR_COL_DECL_LENGTH,
       CHAR_USED,
       --DATA_TYPE_MOD,
       --DATA_TYPE_OWNER,
       --CHAR_LENGTH,
       --COLLATION,
       ORDER_NUM,
       ORIGIN_CON_ID
from INT$DBA_HIER_COLUMNS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, HIER_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
