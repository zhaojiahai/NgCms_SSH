create view ALL_XTERNAL_LOC_SUBPARTITIONS as
select u.name, po.name, po.subname, so.subname, xl.name, 'SYS',
       nvl(xl.dir, xt.default_dir)
from sys.external_location$ xl, sys.external_tab$ xt, obj$ po, obj$ so,
     tabcompart$ tcp, tabsubpart$ tsp, tab$ t, user$ u
where so.obj# = xl.obj# and
      so.obj# = xt.obj# and
      so.obj# = tsp.obj# and
      po.obj# = tcp.obj# and
      tcp.obj# = tsp.pobj# and
      tcp.bo# = t.obj# and
      u.user# = po.owner# and
      po.namespace = 1 and
      po.remoteowner IS NULL and
      po.linkname IS NULL and
      so.namespace = 1 and
      so.remoteowner IS NULL and
      so.linkname IS NULL and
      ((po.owner# = userenv('SCHEMAID') and so.owner# = userenv('SCHEMAID'))
        or tcp.bo# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
        or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -397/* READ ANY TABLE */)
                )
      )
