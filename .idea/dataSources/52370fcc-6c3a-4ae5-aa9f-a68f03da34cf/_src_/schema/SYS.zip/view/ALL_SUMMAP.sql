create view ALL_SUMMAP as
select XID, COMMIT_SCN from sys.snap_xcmt$
