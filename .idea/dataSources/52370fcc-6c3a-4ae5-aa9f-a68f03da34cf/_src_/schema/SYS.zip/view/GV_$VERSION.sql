create view GV_$VERSION as
select "INST_ID","BANNER","CON_ID" from gv$version
