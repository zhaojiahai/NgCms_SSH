create view ALL_EDITIONING_VIEWS as
select ev_user.name, ev_obj.name, ev.base_tbl_name 
from   sys."_CURRENT_EDITION_OBJ" ev_obj, sys.ev$ ev, sys.user$ ev_user
where
       /* join EV$ to _*_EDITION_OBJ on EV id so we can determine */
       /* name of the EV and id of its owner */
       ev_obj.obj# = ev.ev_obj#
       /* join _*_EDITION_OBJ row pertaining to EV to USER$ to get */
       /* EV owner name */
  and  ev_obj.owner# = ev_user.user#
       /* make sure the EV is visible to the current user */
  and  (ev_obj.owner# = userenv('SCHEMAID')
        or ev_obj.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where oa.grantee# in ( select kzsrorol
                                         from x$kzsro
                                  )
            )
        or /* user has system privileges */
         ora_check_sys_privilege (ev_obj.owner#, ev_obj.type#) = 1
      )
