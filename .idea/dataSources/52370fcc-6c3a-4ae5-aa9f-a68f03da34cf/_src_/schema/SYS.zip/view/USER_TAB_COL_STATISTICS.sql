create view USER_TAB_COL_STATISTICS as
select table_name, column_name, num_distinct, low_value, high_value,
       density, num_nulls, num_buckets, last_analyzed, sample_size,
       global_stats, user_stats, notes, avg_col_len, HISTOGRAM,
       'SHARED'
from user_tab_cols_v$
where last_analyzed is not null
union all
select /* fixed table column stats */
       ft.kqftanam, c.kqfconam,
       h.distcnt, h.lowval, h.hival,
       h.density, h.null_cnt,
       case when nvl(h.distcnt,0) = 0 then h.distcnt
            when h.row_cnt = 0 then 1
	    when exists(select 1 from sys."_HISTGRM_DEC" hg
                        where c.kqfcotob = hg.obj# and c.kqfcocno = hg.intcol#
                          and hg.ep_repeat_count > 0 and rownum < 2)
                then h.row_cnt
             when (bitand(h.spare2, 32) > 0 or h.bucket_cnt > 2049 or
                   (h.bucket_cnt >= h.distcnt and h.density*h.bucket_cnt < 1))
                then h.row_cnt
            else h.bucket_cnt
       end,
       h.timestamp#, h.sample_size,
       decode(bitand(h.spare2, 2), 2, 'YES', 'NO'),
       decode(bitand(h.spare2, 1), 1, 'YES', 'NO'),
       null, -- notes
       h.avgcln,
       case when nvl(h.row_cnt,0) = 0 then 'NONE'
            when exists(select 1 from sys."_HISTGRM_DEC" hg
                        where c.kqfcotob = hg.obj# and c.kqfcocno = hg.intcol#
                          and hg.ep_repeat_count > 0 and rownum < 2) then 'HYBRID'
            when (bitand(h.spare2, 32) > 0 or h.bucket_cnt > 2049 or
                  (h.bucket_cnt >= h.distcnt and h.density*h.bucket_cnt < 1))
                then 'FREQUENCY'
            else 'HEIGHT BALANCED'
       end,
       'SHARED'
from   sys.x$kqfta ft, sys.fixed_obj$ fobj,
         sys.x$kqfco c, sys."_HIST_HEAD_DEC" h
where
       ft.kqftaobj = fobj. obj#
       and c.kqfcotob = ft.kqftaobj
       and h.obj# = ft.kqftaobj
       and h.intcol# = c.kqfcocno
       /*
        * if fobj and st are not in sync (happens when db open read only
        * after upgrade), do not display stats.
        */
       and ft.kqftaver =
             fobj.timestamp - to_date('01-01-1991', 'DD-MM-YYYY')
       and h.timestamp# is not null
       and userenv('SCHEMAID') = 0  /* SYS */
UNION ALL
select /* session private stats for GTT */
       o.name                  table_name,
       c.name                  column_name,
       h.distcnt_kxttst_cs     num_distinct,
       h.lowval_kxttst_cs      low_value,
       h.hival_kxttst_cs       high_value,
       h.density_kxttst_cs     density,
       h.null_cnt_kxttst_cs    num_nulls,
       case when nvl(h.distcnt_kxttst_cs,0) = 0 then h.distcnt_kxttst_cs
            when h.row_cnt_kxttst_cs = 0 then 1
            when exists(select 1 from sys.x$kxttstehs hg
                        where c.obj# = hg.obj#_kxttst_hs
                          and c.intcol# = hg.intcol#_kxttst_hs
                          and hg.ep_repeat_count_kxttst_hs > 0
                          and rownum < 2)
                 then h.row_cnt_kxttst_cs
            when bitand(h.spare2_kxttst_cs, 64) > 0
                then h.row_cnt_kxttst_cs
	    when (bitand(h.spare2_kxttst_cs, 32) > 0 or
                  h.bucket_cnt_kxttst_cs > 2049 or
                  (h.bucket_cnt_kxttst_cs > h.distcnt_kxttst_cs
                   and h.row_cnt_kxttst_cs = h.distcnt_kxttst_cs
                   and h.density_kxttst_cs*h.bucket_cnt_kxttst_cs < 1))
                then h.row_cnt_kxttst_cs
            else h.bucket_cnt_kxttst_cs
       end num_buckets,
       h.timestamp#_kxttst_cs  last_analyzed,
       h.sample_size_kxttst_cs sample_size,
       decode(bitand(h.spare2_kxttst_cs, 2), 2, 'YES', 'NO') global_stats,
       decode(bitand(h.spare2_kxttst_cs, 1), 1, 'YES', 'NO') user_stats,
       null,  -- notes,
       h.avgcln_kxttst_cs      avg_col_len,
       case when nvl(h.row_cnt_kxttst_cs,0) = 0 then 'NONE'
            when exists(select 1 from sys.x$kxttstehs hg
                        where c.obj# = hg.obj#_kxttst_hs
                          and c.intcol# = hg.intcol#_kxttst_hs
                          and hg.ep_repeat_count_kxttst_hs > 0
                          and rownum < 2) then 'HYBRID'
            when bitand(h.spare2_kxttst_cs, 64) > 0
              then 'TOP-FREQUENCY'
            when (bitand(h.spare2_kxttst_cs, 32) > 0 or
                  h.bucket_cnt_kxttst_cs > 2049 or
                  (h.bucket_cnt_kxttst_cs >= h.distcnt_kxttst_cs
                   and h.density_kxttst_cs*h.bucket_cnt_kxttst_cs < 1))
                then 'FREQUENCY'
            else 'HEIGHT BALANCED'
       end,
       'SESSION'               scope
from x$kxttstecs h, obj$ o, col$ c, user_tables t
where h.obj#_kxttst_cs = o.obj# and
      o.name = t.table_name and
      c.obj# = o.obj# and
      h.intcol#_kxttst_cs = c.intcol#
