create view GV_$REPLAY_CONTEXT_SYSDATE as
select "INST_ID","CONTEXT_ID","SYSDATE_VALUE","REPLAYED","CON_ID" from gv$replay_context_sysdate
