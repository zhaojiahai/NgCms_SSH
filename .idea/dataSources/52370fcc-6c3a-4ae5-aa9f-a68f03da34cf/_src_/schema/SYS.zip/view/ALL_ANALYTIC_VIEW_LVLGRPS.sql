create view ALL_ANALYTIC_VIEW_LVLGRPS as
select owner,
       ANALYTIC_VIEW_NAME,
       MVIEW_NAME,
       CACHE_TYPE,
       DIMENSION_ALIAS,
       HIER_ALIAS,
       LEVEL_NAME,
       MEASURE_NAME,
       AV_LVLGRP_ORDER,
       LEVEL_MEAS_ORDER,
       ORIGIN_CON_ID
from INT$DBA_AVIEW_LVLGRPS
where OWNER = SYS_CONTEXT('USERENV', 'CURRENT_USER')
       or OWNER='PUBLIC'
       or OBJ_ID(OWNER, ANALYTIC_VIEW_NAME, OBJECT_TYPE, OBJECT_ID) in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or ora_check_sys_privilege(owner_id, object_type) = 1
