create view GV_$BLOCKING_QUIESCE as
select "INST_ID","SID","CON_ID" from gv$blocking_quiesce
