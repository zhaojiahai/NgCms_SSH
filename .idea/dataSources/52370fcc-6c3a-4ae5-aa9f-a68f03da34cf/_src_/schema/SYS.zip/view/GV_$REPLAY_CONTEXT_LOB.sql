create view GV_$REPLAY_CONTEXT_LOB as
select "INST_ID","CONTEXT_ID","LOB_ID","LOB_VERSION_BASE","LOB_VERSION_WRAP","MATCHED","CON_ID" from gv$replay_context_lob
