create view V_$DIAG_INFO as
select "INST_ID","NAME","VALUE","CON_ID" from v$diag_info
