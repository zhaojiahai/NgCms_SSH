create view ALL_SUBPARTITION_TEMPLATES as
select u.name, o.name, st.spart_name, st.spart_position + 1, ts.name,
       st.hiboundval,
       decode(bitand(st.flags, 3), 2, 'NO', 1, 'YES', 'NONE'),
       decode(bitand(st.flags, 192), 128, 'OFF', 64, 'ON', 'NONE'),
       decode(bitand(st.flags, 402653184), 268435456, 'NO',
       134217728, 'YES', 'NONE')
from sys.obj$ o, sys.defsubpart$ st, sys.ts$ ts, sys.user$ u
where st.bo# = o.obj# and st.ts# = ts.ts#(+) and o.owner# = u.user# and
      o.subname IS NULL and
      o.namespace = 1 and o.remoteowner IS NULL and o.linkname IS NULL and
      (o.owner# = userenv('SCHEMAID') or
       o.obj# in (select oa.obj# from sys.objauth$ oa
                  where grantee# in ( select kzsrorol from x$kzsro )) or
       exists (select null from v$enabledprivs
               where priv_number in (-45 /* LOCK ANY TABLE */,
                                     -47 /* SELECT ANY TABLE */,
                                     -397/* READ ANY TABLE */,
                                     -48 /* INSERT ANY TABLE */,
                                     -49 /* UPDATE ANY TABLE */,
                                     -50 /* DELETE ANY TABLE */)))
