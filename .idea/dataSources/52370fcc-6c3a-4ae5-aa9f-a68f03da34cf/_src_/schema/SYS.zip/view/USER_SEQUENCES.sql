create view USER_SEQUENCES as
select o.name,
      s.minvalue, s.maxvalue, s.increment$,
      decode (s.cycle#, 0, 'N', 1, 'Y'),
      decode (s.order$, 0, 'N', 1, 'Y'),
      s.cache, s.highwater,
      decode(bitand(s.flags, 16), 16, 'Y', 'N'),
      decode(bitand(s.flags, 2048), 2048, 'Y', 'N'),
      decode(bitand(s.flags, 64), 64, 'Y', 'N'),
      decode(bitand(s.flags, 512), 512, 'Y', 'N')
from sys.seq$ s, sys.obj$ o
where o.owner# = userenv('SCHEMAID')
  and o.obj# = s.obj#
  and (bitand(s.flags, 1024) = 0 or s.flags is null)
